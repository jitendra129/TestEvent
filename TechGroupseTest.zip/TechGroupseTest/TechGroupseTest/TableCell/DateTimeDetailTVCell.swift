//
//  DateTimeDetailTVCell.swift
//  TechGroupseTest
//
//  Created by Mihir on 30/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//

import UIKit

class DateTimeDetailTVCell: UITableViewCell {
    @IBOutlet weak var lblDate:UILabel!
       @IBOutlet weak var lblTime:UILabel!
       @IBOutlet weak var lblLang:UILabel!
       @IBOutlet weak var lblMale:UILabel!
       @IBOutlet weak var lblYear:UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

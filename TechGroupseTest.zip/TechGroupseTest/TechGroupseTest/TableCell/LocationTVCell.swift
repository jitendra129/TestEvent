//
//  LocationTVCell.swift
//  TechGroupseTest
//
//  Created by Mihir on 30/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//

import UIKit

class LocationTVCell: UITableViewCell {
    @IBOutlet weak var lblAddress:UILabel!
          @IBOutlet weak var lblLoc:UILabel!
          @IBOutlet weak var lblLang:UILabel!
      
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

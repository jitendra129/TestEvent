//
//  AppDelegate.swift
//  TechGroupseTest
//
//  Created by Mihir on 29/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
         let storyboard = UIStoryboard(name: "Main", bundle: nil)
         let mainViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
         let nvc: UINavigationController = UINavigationController(rootViewController: mainViewController)
        
        self.window?.rootViewController = nvc
        self.window?.makeKeyAndVisible()
        return true
    }

      


}


//
//  SectionHeaderView.swift
//  TechGroupseTest
//
//  Created by Mihir on 30/06/20.
//  Copyright © 2020 Mihir. All rights reserved.
//

import UIKit

class SectionHeaderView: UIView {

    
 
    
    override func layoutSubviews() {
           self.frame = CGRect(x: 0, y: 0, width: kDeviceWidth, height: 60)
       }
       
       class func instanceFromNib() -> SectionHeaderView
       {
           return Bundle.main.loadNibNamed("SectionHeaderView", owner: self, options: nil)?[0] as? SectionHeaderView ?? SectionHeaderView()
       }

}
